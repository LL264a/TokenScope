import urllib.request, json, ssl, sqlite3
ctx = ssl.create_default_context(); ctx.check_hostname=False; ctx.verify_mode=ssl.CERT_NONE

req = urllib.request.Request("https://127.0.0.1/api/auth/login", data=b'{"password":"admin123"}', headers={"Host":"ait.ll264a.cn","Content-Type":"application/json"})
with urllib.request.urlopen(req, context=ctx) as r:
    token = json.loads(r.read())["token"]

db = sqlite3.connect("/www/wwwroot/ait.ll264a.cn/data/token_monitor.db")
rows = db.execute("SELECT credential_type FROM credentials WHERE platform='deepseek'").fetchall()
types = [r[0] for r in rows]
print("Current DeepSeek credential types:", types)

if "token" not in types:
    print("MISSING userToken! Need to visit DeepSeek page.")
    # Simulate pushing a fake userToken so we can at least test
    req = urllib.request.Request("https://127.0.0.1/api/admin/credentials",
        data=json.dumps({"platform":"deepseek","credential_type":"token","credential_data":"test_token_value","note":"test push from script"}).encode(),
        headers={"Host":"ait.ll264a.cn","Content-Type":"application/json","Authorization":"Bearer "+token})
    with urllib.request.urlopen(req, context=ctx) as r:
        d = json.loads(r.read())
        print("Fake token push result:", d)
else:
    print("Has userToken, should show usage")
db.close()
