import urllib.request, json, ssl
ctx = ssl.create_default_context(); ctx.check_hostname=False; ctx.verify_mode=ssl.CERT_NONE

req = urllib.request.Request("https://127.0.0.1/api/auth/login", data=b'{"password":"admin123"}', headers={"Host":"ait.ll264a.cn","Content-Type":"application/json"})
with urllib.request.urlopen(req, context=ctx) as r:
    token = json.loads(r.read())["token"]

req = urllib.request.Request("https://127.0.0.1/api/admin/check_credential", data=json.dumps({"platform":"deepseek"}).encode(), headers={"Host":"ait.ll264a.cn","Content-Type":"application/json","Authorization":"Bearer "+token})
with urllib.request.urlopen(req, context=ctx) as r:
    d = json.loads(r.read())
    print(json.dumps(d, ensure_ascii=False, indent=2))
